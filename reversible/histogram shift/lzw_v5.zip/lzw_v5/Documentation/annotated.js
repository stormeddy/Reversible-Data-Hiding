var annotated =
[
    [ "EncoderDictionary", "class_encoder_dictionary.html", "class_encoder_dictionary" ]
];