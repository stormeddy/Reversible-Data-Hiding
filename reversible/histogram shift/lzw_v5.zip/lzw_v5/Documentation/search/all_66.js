var searchData=
[
  ['first',['first',['../struct_encoder_dictionary_1_1_node.html#a403847ab54114481cff9a891d77c02a3',1,'EncoderDictionary::Node']]]
];
