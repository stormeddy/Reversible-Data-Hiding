var searchData=
[
  ['initials',['initials',['../class_encoder_dictionary.html#aab5d1599dc520ebde557907344a6ab68',1,'EncoderDictionary']]]
];
